const output = document.querySelector("#output");

const Figure = document.createElement("figure");

const span = document.innerHTML("")

let chat = document.getElementById("mascot"),figure;

if (chat === "mascot") {
chat.parentNode.replaceChild(figure, chat);
} else {
    
}
