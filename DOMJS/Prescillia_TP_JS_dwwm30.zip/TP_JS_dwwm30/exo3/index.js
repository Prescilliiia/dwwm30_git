const btn = document.querySelector("button");
console.log(btn);



btn.addEventListener("click",() =>{

nombre=3
    for (let i = 1; i < 10; ++i) {
      document.write("3*"+ i +" = " + 3* i + "<br>") ;
      }

});