const btn = document.querySelector("button");

btn.addEventListener("click",() =>{
    btn.innerHTML = "Vous m'avez cliqué";

})