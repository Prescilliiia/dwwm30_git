# Notes du cours

## Conventions de nommage

Nous utiliserons la convention camelCase
elle consiste à commencer un nom de fichier de dossier ou de variables et plus généralement d'éléments de code par une minuscule puis pour chaque mot du titre utiliser une majuscule
ex:

> nombreDePersonnes

> classePrincipale

etc.

## Retour à la ligne automatique

alt + z : word-wrap (retour à la ligne automatique)
